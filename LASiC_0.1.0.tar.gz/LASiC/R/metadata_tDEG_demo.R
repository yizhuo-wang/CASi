#' The meta data of the LASiClist_tDEG_demo data
#' contains the Group and Time variables.
#'
#' @docType data
#'
#' @usage data(metadata_tDEG_demo)
#'
#' @keywords datasets
"metadata_tDEG_demo"

