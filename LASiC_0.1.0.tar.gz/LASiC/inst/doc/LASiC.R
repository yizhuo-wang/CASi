## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
# install.packages("LASiC")
library(LASiC)

## ----message=FALSE, warning=FALSE, include=FALSE------------------------------
# install.packages("tensorflow")
# install.packages("reticulate")  
# 
# library(reticulate)
# install_miniconda()
# # use_condaenv("r-miniconda", required = TRUE)
# 
# library(tensorflow)
# library(keras)

# library(tensorflow)
# library(keras)
# library(Seurat)
# library(umap)
# library(dplyr)
# library(ggplot2)
# library(stringr)

## -----------------------------------------------------------------------------
data(pbmc_demo)
names(pbmc_demo)

## ----message=FALSE, warning=FALSE---------------------------------------------
l1 <- createLASiClist(t0_count = as.matrix(pbmc_demo[[1]]), t1_count = as.matrix(pbmc_demo[[3]]), t0_label = pbmc_demo[[2]])

## -----------------------------------------------------------------------------
names(l1)

## ----message=FALSE, warning=FALSE---------------------------------------------
l1 <- CrossTimeAnnotation(l1)

## ----message=FALSE, warning=FALSE---------------------------------------------
names(l1)

## ----message=FALSE, warning=FALSE---------------------------------------------
l1 <- DetectNovelCells(l1)

## -----------------------------------------------------------------------------
names(l1)

## -----------------------------------------------------------------------------
data("LASiClist_tDEG_demo")
data("metadata_tDEG_demo")

summary(metadata_tDEG_demo)

nCell_t0 <- length(LASiClist_tDEG_demo[[2]])
nCell_t1 <- length(LASiClist_tDEG_demo[[6]])
nCell_t0 + nCell_t1

## ----message=FALSE, warning=FALSE---------------------------------------------
l2 <- FindTemporalDEGs(LASiClist_tDEG_demo, metadata_tDEG_demo)

## -----------------------------------------------------------------------------
names(l2)

